'use client';

export default function AidaLuxuryWebsite() {
  return (
    <div className="bg-black text-white min-h-screen overflow-hidden">

      <header className="fixed top-0 left-0 w-full z-50 bg-black/40 backdrop-blur-2xl border-b border-white/10 px-6 py-4 flex items-center justify-between">
        <div className="flex items-center gap-4">
          <img src="/aida-logo.png" alt="AIDA Logo" className="w-12 h-12 object-contain" />
          <div>
            <h1 className="text-2xl tracking-[0.45em] font-extralight">AIDA</h1>
            <p className="text-[10px] tracking-[0.35em] uppercase text-white/60 mt-1">
              Luxury Fashion House
            </p>
          </div>
        </div>

        <nav className="hidden md:flex items-center gap-10 text-sm uppercase tracking-[0.25em] text-white/70">
          <a href="#home">Home</a>
          <a href="#collections">Collections</a>
          <a href="#shop">Shop</a>
          <a href="#contact">Contact</a>
        </nav>
      </header>

      <section id="home" className="relative h-screen flex items-center justify-center">
        <img
          src="https://images.unsplash.com/photo-1529139574466-a303027c1d8b?q=80&w=2200&auto=format&fit=crop"
          className="absolute inset-0 w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-black/60" />

        <div className="relative z-10 text-center">
          <h1 className="text-6xl md:text-8xl font-extralight tracking-[0.4em]">
            AIDA
          </h1>
          <p className="mt-6 text-white/70">Modern luxury boutique</p>
        </div>
      </section>

      <section id="shop" className="py-32 px-6 bg-black">
        <div className="max-w-6xl mx-auto grid md:grid-cols-3 gap-10">

          {[
            { name: "Pink Dress", price: "₹950", img: "https://images.unsplash.com/photo-1585487000160-6ebcfceb0d03" },
            { name: "White Frock", price: "₹2000", img: "https://images.unsplash.com/photo-1520975958225-8b5f6a3b2b5b" },
            { name: "Floral Dress", price: "₹1750", img: "https://images.unsplash.com/photo-1506629905607-d9c297d15d11" }
          ].map((item, i) => (
            <div key={i} className="bg-white text-black rounded-2xl overflow-hidden">
              <img src={item.img} className="h-[400px] w-full object-cover" />
              <div className="p-6 text-center">
                <h3>{item.name}</h3>
                <p>{item.price}</p>
              </div>
            </div>
          ))}

        </div>
      </section>

      <footer className="py-10 text-center border-t border-white/10">
        <p>AIDA © 2026</p>
      </footer>

    </div>
  );
}
